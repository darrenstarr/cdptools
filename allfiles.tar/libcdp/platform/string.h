#ifdef __KERNEL__
#include <linux/string.h>
#else
#include <string.h>
#endif
