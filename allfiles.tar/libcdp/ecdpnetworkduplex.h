#ifndef ECDPNETWORKDUPLEX_H
#define ECDPNETWORKDUPLEX_H

typedef enum
{
	DuplexUnset = 0,
	DuplexHalf = 2,
	DuplexFull = 1
} ECdpNetworkDuplex;

#endif
